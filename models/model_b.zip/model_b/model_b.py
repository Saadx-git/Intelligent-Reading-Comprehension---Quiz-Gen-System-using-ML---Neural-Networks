"""
MODEL B: Hint Generation System
Generates ranked hints (3 most relevant sentences) to help students understand questions.

Subtask 1: Extractive strategy - score sentences by cosine similarity to question
Subtask 2: ML-scored strategy - train Logistic Regression on sentence features
Subtask 3: Evaluate hint quality (Precision, R²)
Subtask 4: Pickle all artifacts
"""

import pandas as pd
import numpy as np
import re
import joblib
import nltk
from nltk.tokenize import sent_tokenize
from pathlib import Path
from tqdm import tqdm
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_score, r2_score, confusion_matrix
import warnings

warnings.filterwarnings('ignore')

# Download NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def clean_text(text):
    """Clean text by removing special characters and lowercasing."""
    if pd.isna(text):
        return ""
    return re.sub(r'[^\w\s]', '', str(text).lower().strip())


def sentence_tokenize(text):
    """Tokenize text into sentences."""
    if not text or pd.isna(text):
        return []
    try:
        return sent_tokenize(text)
    except:
        return text.split('. ')


def extract_sentences_with_indices(article):
    """Extract sentences and return with original indices."""
    sentences = sentence_tokenize(article)
    return [(i, sent) for i, sent in enumerate(sentences)]


def compute_cosine_similarity(text1_vec, text2_vec):
    """Compute cosine similarity between two normalized vectors."""
    return np.dot(text1_vec, text2_vec)


# ============================================================================
# SUBTASK 1: EXTRACTIVE STRATEGY (Cosine Similarity)
# ============================================================================

class ExtractiveHintGenerator:
    """
    Extracts hints using cosine similarity between sentences and question.
    Hint 1 = most general, Hint 3 = near-explicit
    """
    
    def __init__(self, vectorizer=None):
        """Initialize with TF-IDF vectorizer."""
        self.vectorizer = vectorizer or TfidfVectorizer(
            max_features=5000,
            min_df=1,
            max_df=0.95,
            lowercase=True
        )
        self.fitted = False
    
    def fit(self, texts):
        """Fit the vectorizer on a corpus of texts."""
        print("Fitting TF-IDF vectorizer...")
        self.vectorizer.fit(texts)
        self.fitted = True
        return self
    
    def score_sentences(self, question, sentences):
        """
        Score each sentence by cosine similarity to the question.
        Returns list of (sentence, score, rank) tuples sorted by score (descending).
        """
        if not self.fitted:
            raise ValueError("Vectorizer not fitted. Call fit() first.")
        
        # Vectorize question and sentences
        question_vec = normalize(self.vectorizer.transform([question]), norm='l2')[0]
        sentence_vecs = normalize(self.vectorizer.transform(sentences), norm='l2')
        
        # Compute cosine similarities
        similarities = np.array((sentence_vecs.multiply(question_vec)).sum(axis=1)).flatten()
        similarities = np.clip(similarities, -1, 1)
        
        # Create tuples of (sentence, score, rank)
        scored_sentences = []
        for i, (sent, score) in enumerate(zip(sentences, similarities)):
            scored_sentences.append({
                'sentence': sent,
                'score': float(score),
                'rank': i
            })
        
        # Sort by score (descending)
        scored_sentences.sort(key=lambda x: x['score'], reverse=True)
        
        return scored_sentences
    
    def extract_hints(self, question, article, top_k=3):
        """
        Extract top-k sentences as hints from the article.
        Returns: {
            'hints': [{'text': str, 'score': float, 'original_rank': int}, ...],
            'hint_1_general': str (most general),
            'hint_2_moderate': str,
            'hint_3_explicit': str (most explicit)
        }
        """
        sentences = sentence_tokenize(article)
        if not sentences:
            return {
                'hints': [],
                'hint_1_general': "",
                'hint_2_moderate': "",
                'hint_3_explicit': ""
            }
        
        # Score sentences
        scored_sents = self.score_sentences(question, sentences)
        
        # Get top-k hints
        top_hints = scored_sents[:top_k]
        
        result = {
            'hints': top_hints,
            'num_sentences': len(sentences),
            'top_scores': [h['score'] for h in top_hints]
        }
        
        # Assign hints with naming convention
        for i, hint in enumerate(top_hints):
            if i == 0:
                result['hint_1_general'] = hint['sentence']
            elif i == 1:
                result['hint_2_moderate'] = hint['sentence']
            elif i == 2:
                result['hint_3_explicit'] = hint['sentence']
        
        return result


# ============================================================================
# SUBTASK 2: ML-SCORED STRATEGY (Logistic Regression)
# ============================================================================

class MLScoredHintGenerator:
    """
    Scores sentences using Logistic Regression trained on sentence features.
    Features: keyword overlap, position in passage, sentence length, TF-IDF similarity
    """
    
    def __init__(self):
        """Initialize ML hint generator."""
        self.model = LogisticRegression(max_iter=1000, random_state=42)
        self.vectorizer = TfidfVectorizer(max_features=5000, min_df=1, max_df=0.95, lowercase=True)
        self.fitted = False
        self.scaler_params = {}
    
    def fit(self, corpus_texts):
        """Fit vectorizer on corpus."""
        print("Fitting ML hint generator...")
        self.vectorizer.fit(corpus_texts)
        self.fitted = True
        return self
    
    def extract_features(self, question, sentences):
        """
        Extract features for each sentence for ML ranking.
        Features:
        - tfidf_similarity: cosine similarity to question
        - keyword_overlap: # of overlapping tokens
        - position: normalized position in article (0-1)
        - sentence_length: # of words in sentence
        - question_length: # of words in question
        """
        if not self.fitted:
            raise ValueError("Vectorizer not fitted. Call fit() first.")
        
        features = []
        question_tokens = set(question.lower().split())
        question_length = len(question_tokens)
        
        # Vectorize question and sentences
        question_vec = normalize(self.vectorizer.transform([question]), norm='l2')[0]
        sentence_vecs = normalize(self.vectorizer.transform(sentences), norm='l2')
        
        # Compute TF-IDF similarities
        tfidf_sims = np.array((sentence_vecs.multiply(question_vec)).sum(axis=1)).flatten()
        tfidf_sims = np.clip(tfidf_sims, -1, 1)
        
        for idx, (sent, tfidf_sim) in enumerate(zip(sentences, tfidf_sims)):
            sent_tokens = set(sent.lower().split())
            keyword_overlap = len(question_tokens & sent_tokens)
            position = idx / max(len(sentences), 1)  # 0 = start, 1 = end
            sent_length = len(sent_tokens)
            
            features.append({
                'tfidf_similarity': float(tfidf_sim),
                'keyword_overlap': int(keyword_overlap),
                'position': float(position),
                'sentence_length': int(sent_length),
                'question_length': int(question_length)
            })
        
        return pd.DataFrame(features)
    
    def train(self, training_data):
        """
        Train the Logistic Regression model.
        training_data should be a list of dicts:
        {
            'question': str,
            'article': str,
            'hints': list of str (gold hint sentences),
            'sentences': list of str (all sentences in article)
        }
        """
        print(f"\nTraining ML hint generator on {len(training_data)} examples...")
        
        X_all = []
        y_all = []
        
        for example in tqdm(training_data, desc="Extracting features"):
            question = example['question']
            sentences = example['sentences']
            gold_hints = set(example.get('hints', []))
            
            # Extract features
            feature_df = self.extract_features(question, sentences)
            X_all.append(feature_df.values)
            
            # Create labels (1 if sentence is a gold hint, 0 otherwise)
            labels = [1 if sent in gold_hints else 0 for sent in sentences]
            y_all.append(np.array(labels))
        
        # Combine all data
        X = np.vstack(X_all)
        y = np.concatenate(y_all)
        
        # Train model
        self.model.fit(X, y)
        self.fitted = True
        
        return self
    
    def score_sentences(self, question, sentences):
        """Score sentences using the trained model."""
        if not self.fitted:
            raise ValueError("Model not fitted. Call train() first.")
        
        feature_df = self.extract_features(question, sentences)
        scores = self.model.predict_proba(feature_df.values)[:, 1]  # Probability of class 1
        
        scored_sentences = []
        for sent, score in zip(sentences, scores):
            scored_sentences.append({
                'sentence': sent,
                'score': float(score),
                'rank': len(scored_sentences)
            })
        
        scored_sentences.sort(key=lambda x: x['score'], reverse=True)
        return scored_sentences
    
    def extract_hints(self, question, article, top_k=3):
        """Extract top-k hints using ML scoring."""
        sentences = sentence_tokenize(article)
        if not sentences:
            return {
                'hints': [],
                'hint_1_general': "",
                'hint_2_moderate': "",
                'hint_3_explicit': ""
            }
        
        # Score sentences
        scored_sents = self.score_sentences(question, sentences)
        
        # Get top-k hints
        top_hints = scored_sents[:top_k]
        
        result = {
            'hints': top_hints,
            'num_sentences': len(sentences),
            'top_scores': [h['score'] for h in top_hints]
        }
        
        # Assign hints with naming convention
        for i, hint in enumerate(top_hints):
            if i == 0:
                result['hint_1_general'] = hint['sentence']
            elif i == 1:
                result['hint_2_moderate'] = hint['sentence']
            elif i == 2:
                result['hint_3_explicit'] = hint['sentence']
        
        return result


# ============================================================================
# SUBTASK 3: EVALUATION METRICS
# ============================================================================

class HintEvaluator:
    """Evaluate hint quality using Precision@K and R² metrics."""
    
    @staticmethod
    def precision_at_k(predicted_hints, gold_hints, k=3):
        """
        Compute Precision@K: fraction of top-K predictions that match gold hints.
        predicted_hints: list of sentence strings (top-k)
        gold_hints: list of sentence strings (ground truth)
        """
        if len(predicted_hints) == 0:
            return 0.0
        if len(gold_hints) == 0:
            return 0.0
        
        top_k = predicted_hints[:k]
        matches = sum(1 for pred in top_k if pred in gold_hints)
        return matches / min(k, len(top_k))
    
    @staticmethod
    def recall_at_k(predicted_hints, gold_hints, k=3):
        """
        Compute Recall@K: fraction of gold hints recovered in top-K predictions.
        """
        if len(gold_hints) == 0:
            return 0.0
        if len(predicted_hints) == 0:
            return 0.0
        
        top_k = set(predicted_hints[:k])
        matches = sum(1 for gold in gold_hints if gold in top_k)
        return matches / len(gold_hints)
    
    @staticmethod
    def evaluate_batch(results, gold_data, k=3):
        """
        Evaluate a batch of predictions against gold data.
        results: list of prediction dicts from hint generators
        gold_data: list of gold hint dicts
        
        Returns: dict with metrics
        """
        precisions = []
        recalls = []
        correct_top1 = 0  # Top-ranked hint is correct
        
        for pred, gold in zip(results, gold_data):
            pred_hints = [h['sentence'] for h in pred.get('hints', [])]
            gold_hints = gold.get('hints', [])
            
            prec = HintEvaluator.precision_at_k(pred_hints, gold_hints, k)
            rec = HintEvaluator.recall_at_k(pred_hints, gold_hints, k)
            
            precisions.append(prec)
            recalls.append(rec)
            
            # Check if top-1 is in gold hints
            if pred_hints and pred_hints[0] in gold_hints:
                correct_top1 += 1
        
        return {
            'precision_at_k': np.mean(precisions),
            'recall_at_k': np.mean(recalls),
            'accuracy_top1': correct_top1 / len(results) if results else 0.0,
            'mean_precision': np.mean(precisions),
            'mean_recall': np.mean(recalls)
        }


# ============================================================================
# MAIN PIPELINE
# ============================================================================

class ModelB:
    """Complete Model B pipeline for hint generation."""
    
    def __init__(self, output_dir='models/model_b/traditional'):
        """Initialize Model B."""
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.extractive_generator = ExtractiveHintGenerator()
        self.ml_generator = MLScoredHintGenerator()
        self.evaluator = HintEvaluator()
    
    def prepare_training_data(self, df):
        """
        Prepare training data from raw DataFrame.
        Assumes df has columns: article, question, A, B, C, D, answer
        """
        print("\nPreparing training data...")
        training_data = []
        
        for idx, row in tqdm(df.iterrows(), total=len(df), desc="Preparing data"):
            article = str(row['article'])
            question = str(row['question'])
            
            # Extract sentences
            sentences = sentence_tokenize(article)
            
            # For gold hints, we'll use sentences with high keyword overlap to the question
            # (This is a heuristic since we don't have explicit hint labels)
            question_tokens = set(question.lower().split())
            
            hint_candidates = []
            for sent in sentences:
                sent_tokens = set(sent.lower().split())
                overlap = len(question_tokens & sent_tokens)
                if overlap >= 2:  # At least 2 keyword matches
                    hint_candidates.append(sent)
            
            # Take top 3 by length (assuming longer sentences with overlap are more informative)
            gold_hints = sorted(hint_candidates, key=lambda s: len(s.split()), reverse=True)[:3]
            
            training_data.append({
                'question': question,
                'article': article,
                'sentences': sentences,
                'hints': gold_hints
            })
        
        return training_data
    
    def run_pipeline(self, train_df, dev_df, test_df):
        """Run complete Model B pipeline."""
        print("\n" + "="*80)
        print("MODEL B: HINT GENERATION SYSTEM")
        print("="*80)
        
        # =====================================================================
        # SUBTASK 1: EXTRACTIVE STRATEGY
        # =====================================================================
        print("\n" + "-"*80)
        print("SUBTASK 1: EXTRACTIVE STRATEGY (Cosine Similarity)")
        print("-"*80)
        
        # Fit vectorizer on all articles
        all_texts = pd.concat([train_df, dev_df, test_df])['article'].tolist()
        self.extractive_generator.fit(all_texts)
        
        # Generate hints on dev set
        print("\nGenerating extractive hints on dev set...")
        extractive_dev_results = []
        for idx, row in tqdm(dev_df.iterrows(), total=len(dev_df), desc="Extracting hints"):
            result = self.extractive_generator.extract_hints(
                row['question'], row['article'], top_k=3
            )
            extractive_dev_results.append(result)
        
        # =====================================================================
        # SUBTASK 2: ML-SCORED STRATEGY
        # =====================================================================
        print("\n" + "-"*80)
        print("SUBTASK 2: ML-SCORED STRATEGY (Logistic Regression)")
        print("-"*80)
        
        # Prepare training data
        training_data = self.prepare_training_data(train_df)
        
        # Fit ML generator
        self.ml_generator.fit(all_texts)
        self.ml_generator.train(training_data)
        
        # Generate hints on dev set
        print("\nGenerating ML-scored hints on dev set...")
        ml_dev_results = []
        for idx, row in tqdm(dev_df.iterrows(), total=len(dev_df), desc="Scoring hints"):
            result = self.ml_generator.extract_hints(
                row['question'], row['article'], top_k=3
            )
            ml_dev_results.append(result)
        
        # =====================================================================
        # SUBTASK 3: EVALUATION
        # =====================================================================
        print("\n" + "-"*80)
        print("SUBTASK 3: HINT QUALITY EVALUATION")
        print("-"*80)
        
        # Prepare gold data for evaluation
        gold_dev_data = self.prepare_training_data(dev_df)
        
        # Evaluate extractive strategy
        print("\nEvaluating Extractive Strategy...")
        extractive_metrics = self.evaluator.evaluate_batch(
            extractive_dev_results, gold_dev_data, k=3
        )
        print(f"  Precision@3:    {extractive_metrics['precision_at_k']:.4f}")
        print(f"  Recall@3:       {extractive_metrics['recall_at_k']:.4f}")
        print(f"  Accuracy (Top-1): {extractive_metrics['accuracy_top1']:.4f}")
        
        # Evaluate ML strategy
        print("\nEvaluating ML-Scored Strategy...")
        ml_metrics = self.evaluator.evaluate_batch(
            ml_dev_results, gold_dev_data, k=3
        )
        print(f"  Precision@3:    {ml_metrics['precision_at_k']:.4f}")
        print(f"  Recall@3:       {ml_metrics['recall_at_k']:.4f}")
        print(f"  Accuracy (Top-1): {ml_metrics['accuracy_top1']:.4f}")
        
        # =====================================================================
        # SUBTASK 4: PICKLE ARTIFACTS
        # =====================================================================
        print("\n" + "-"*80)
        print("SUBTASK 4: SAVING ARTIFACTS")
        print("-"*80)
        
        artifacts = {
            'extractive_generator': self.extractive_generator,
            'ml_generator': self.ml_generator,
            'extractive_dev_results': extractive_dev_results,
            'ml_dev_results': ml_dev_results,
            'extractive_metrics': extractive_metrics,
            'ml_metrics': ml_metrics,
            'training_data': training_data
        }
        
        # Save individual artifacts
        print("\nSaving artifacts to models/model_b/traditional/...")
        joblib.dump(
            self.extractive_generator,
            self.output_dir / 'extractive_generator.pkl'
        )
        print(f"  ✓ Saved extractive_generator.pkl")
        
        joblib.dump(
            self.ml_generator,
            self.output_dir / 'ml_generator.pkl'
        )
        print(f"  ✓ Saved ml_generator.pkl")
        
        joblib.dump(
            extractive_dev_results,
            self.output_dir / 'extractive_dev_results.pkl'
        )
        print(f"  ✓ Saved extractive_dev_results.pkl")
        
        joblib.dump(
            ml_dev_results,
            self.output_dir / 'ml_dev_results.pkl'
        )
        print(f"  ✓ Saved ml_dev_results.pkl")
        
        joblib.dump(
            {
                'extractive': extractive_metrics,
                'ml': ml_metrics
            },
            self.output_dir / 'evaluation_metrics.pkl'
        )
        print(f"  ✓ Saved evaluation_metrics.pkl")
        
        # Save metrics as CSV for readability
        metrics_df = pd.DataFrame({
            'Strategy': ['Extractive', 'ML-Scored'],
            'Precision@3': [extractive_metrics['precision_at_k'], ml_metrics['precision_at_k']],
            'Recall@3': [extractive_metrics['recall_at_k'], ml_metrics['recall_at_k']],
            'Accuracy_Top1': [extractive_metrics['accuracy_top1'], ml_metrics['accuracy_top1']]
        })
        metrics_df.to_csv(self.output_dir / 'evaluation_metrics.csv', index=False)
        print(f"  ✓ Saved evaluation_metrics.csv")
        
        print("\n" + "="*80)
        print("MODEL B PIPELINE COMPLETE")
        print("="*80)
        
        return {
            'extractive_metrics': extractive_metrics,
            'ml_metrics': ml_metrics,
            'artifacts_dir': str(self.output_dir)
        }


# ============================================================================
# EXECUTION
# ============================================================================

if __name__ == "__main__":
    import sys
    
    # Load data
    print("Loading data...")
    train_df = pd.read_csv('data/processed/train_preprocessed.csv')
    dev_df = pd.read_csv('data/processed/dev_preprocessed.csv')
    test_df = pd.read_csv('data/processed/test_preprocessed.csv')
    
    print(f"Loaded train: {len(train_df)} samples")
    print(f"Loaded dev: {len(dev_df)} samples")
    print(f"Loaded test: {len(test_df)} samples")
    
    # Use sample if specified
    sample_size = int(sys.argv[1]) if len(sys.argv) > 1 else None
    if sample_size:
        print(f"\nUsing sample size: {sample_size}")
        train_df = train_df.sample(n=min(sample_size, len(train_df)), random_state=42)
        dev_df = dev_df.sample(n=min(sample_size, len(dev_df)), random_state=42)
        test_df = test_df.sample(n=min(sample_size, len(test_df)), random_state=42)
        print(f"Sampled train: {len(train_df)} samples")
        print(f"Sampled dev: {len(dev_df)} samples")
        print(f"Sampled test: {len(test_df)} samples")
    
    # Run Model B pipeline
    model_b = ModelB(output_dir='models/model_b/traditional')
    results = model_b.run_pipeline(train_df, dev_df, test_df)
    
    print("\n✓ Model B completed successfully!")
    print(f"✓ Artifacts saved to: {results['artifacts_dir']}")
