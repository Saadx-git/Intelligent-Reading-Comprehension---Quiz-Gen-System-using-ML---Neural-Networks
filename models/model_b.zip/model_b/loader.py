"""
Model B - Hints Loader and Inference Helper

Quick utilities to load and use the trained hint generation models.
"""

import joblib
import pandas as pd
import warnings
import sys
from pathlib import Path

# Add parent to path to import model_b classes
sys.path.insert(0, str(Path(__file__).parent))
from model_b import ExtractiveHintGenerator, MLScoredHintGenerator

warnings.filterwarnings('ignore')


class ModelBLoader:
    """Load and manage Model B artifacts."""
    
    def __init__(self, artifact_dir='models/model_b/traditional'):
        """Initialize loader from artifact directory."""
        self.artifact_dir = Path(artifact_dir)
        self.extractive_gen = None
        self.ml_gen = None
        self.metrics = None
        self.dev_results_extractive = None
        self.dev_results_ml = None
        self._load_artifacts()
    
    def _load_artifacts(self):
        """Load all pickled artifacts."""
        print("Loading Model B artifacts...")
        
        # Load generators
        extractive_path = self.artifact_dir / 'extractive_generator.pkl'
        if extractive_path.exists():
            self.extractive_gen = joblib.load(extractive_path)
            print(f"  ✓ Loaded extractive_generator")
        
        ml_path = self.artifact_dir / 'ml_generator.pkl'
        if ml_path.exists():
            self.ml_gen = joblib.load(ml_path)
            print(f"  ✓ Loaded ml_generator")
        
        # Load metrics
        metrics_path = self.artifact_dir / 'evaluation_metrics.pkl'
        if metrics_path.exists():
            self.metrics = joblib.load(metrics_path)
            print(f"  ✓ Loaded metrics")
        
        # Load results
        ext_results_path = self.artifact_dir / 'extractive_dev_results.pkl'
        if ext_results_path.exists():
            self.dev_results_extractive = joblib.load(ext_results_path)
            print(f"  ✓ Loaded extractive dev results ({len(self.dev_results_extractive)} examples)")
        
        ml_results_path = self.artifact_dir / 'ml_dev_results.pkl'
        if ml_results_path.exists():
            self.dev_results_ml = joblib.load(ml_results_path)
            print(f"  ✓ Loaded ML dev results ({len(self.dev_results_ml)} examples)")
        
        print()
    
    def get_metrics_summary(self):
        """Get evaluation metrics summary."""
        if not self.metrics:
            return "No metrics loaded"
        
        summary = "=" * 70 + "\n"
        summary += "MODEL B EVALUATION METRICS\n"
        summary += "=" * 70 + "\n\n"
        
        summary += "EXTRACTIVE STRATEGY (Cosine Similarity)\n"
        summary += "-" * 70 + "\n"
        for key, val in self.metrics['extractive'].items():
            summary += f"  {key:.<40} {val:.4f}\n"
        
        summary += "\nML-SCORED STRATEGY (Logistic Regression)\n"
        summary += "-" * 70 + "\n"
        for key, val in self.metrics['ml'].items():
            summary += f"  {key:.<40} {val:.4f}\n"
        
        return summary
    
    def get_extractive_hints(self, question, article, top_k=3):
        """
        Get hints using extractive strategy.
        
        Args:
            question (str): The question text
            article (str): The passage/article text
            top_k (int): Number of hints to return
        
        Returns:
            dict: Hints with scores and metadata
        """
        if not self.extractive_gen:
            raise ValueError("Extractive generator not loaded")
        
        return self.extractive_gen.extract_hints(question, article, top_k)
    
    def get_ml_hints(self, question, article, top_k=3):
        """
        Get hints using ML-scored strategy.
        
        Args:
            question (str): The question text
            article (str): The passage/article text
            top_k (int): Number of hints to return
        
        Returns:
            dict: Hints with ML scores and metadata
        """
        if not self.ml_gen:
            raise ValueError("ML generator not loaded")
        
        return self.ml_gen.extract_hints(question, article, top_k)
    
    def get_dev_result(self, idx, strategy='extractive'):
        """
        Get precomputed result for dev set example.
        
        Args:
            idx (int): Index of example in dev set
            strategy (str): 'extractive' or 'ml'
        
        Returns:
            dict: Hints for that example
        """
        if strategy == 'extractive':
            if not self.dev_results_extractive or idx >= len(self.dev_results_extractive):
                return None
            return self.dev_results_extractive[idx]
        elif strategy == 'ml':
            if not self.dev_results_ml or idx >= len(self.dev_results_ml):
                return None
            return self.dev_results_ml[idx]
        else:
            raise ValueError(f"Unknown strategy: {strategy}")
    
    def print_hints(self, hints_dict, label="Hints"):
        """Pretty-print hints dictionary."""
        print(f"\n{label}")
        print("=" * 70)
        
        if 'hints' in hints_dict:
            for i, hint in enumerate(hints_dict['hints'], 1):
                print(f"\nHint {i} (Score: {hint['score']:.4f})")
                print(f"  {hint['sentence'][:100]}...")
        
        if 'hint_1_general' in hints_dict:
            print(f"\n[Most General]")
            print(f"  {hints_dict['hint_1_general'][:100]}...")
        
        if 'hint_2_moderate' in hints_dict:
            print(f"\n[Moderately Specific]")
            print(f"  {hints_dict['hint_2_moderate'][:100]}...")
        
        if 'hint_3_explicit' in hints_dict:
            print(f"\n[Most Explicit]")
            print(f"  {hints_dict['hint_3_explicit'][:100]}...")


# ============================================================================
# QUICK START EXAMPLES
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("MODEL B - HINTS INFERENCE QUICK START")
    print("=" * 70 + "\n")
    
    # Load models
    loader = ModelBLoader('models/model_b/traditional')
    
    # Print metrics
    print(loader.get_metrics_summary())
    
    # Example: Get precomputed dev result
    print("\nGETTING DEV RESULT (Example 0)")
    print("-" * 70)
    dev_result = loader.get_dev_result(0, strategy='extractive')
    if dev_result:
        print(f"Number of hints: {len(dev_result['hints'])}")
        print(f"Top 3 scores: {dev_result['top_scores']}")
    
    # Example: Generate hints for new question
    print("\n\nGENERATING NEW HINTS")
    print("-" * 70)
    
    sample_question = "Why did the student go to the library?"
    sample_article = """
    The library was the perfect place for study. With its quiet atmosphere,
    abundant resources, and helpful staff, it provided everything needed.
    Many students found it to be their favorite study location. The peaceful
    environment encouraged concentration and learning. Reference materials
    were always available for research projects.
    """
    
    # Get extractive hints
    ext_hints = loader.get_extractive_hints(sample_question, sample_article, top_k=3)
    loader.print_hints(ext_hints, "EXTRACTIVE STRATEGY HINTS")
    
    # Get ML hints
    ml_hints = loader.get_ml_hints(sample_question, sample_article, top_k=3)
    loader.print_hints(ml_hints, "ML-SCORED STRATEGY HINTS")
    
    print("\n" + "=" * 70)
    print("Done!")
    print("=" * 70 + "\n")
